#include <iostream>
#include <map>
#include <string>
#include <set>
#include <vector>
#include <utility>

typedef unsigned long long my_int;

using namespace std;

struct Abonent {
    string Name;
    string Email;
    set <my_int> Phones;
};

class Book {
public:
    vector <Abonent> General;
    map <string, int> Names;
    map <my_int, int> Phones;
    void add_new (string, my_int, string = "null");
    void output_all () const;
    void add_phone (string name, my_int phone);
    void replace_phone (string name, my_int old_phone, my_int new_phone);
    void find_name (my_int phone);
};
