#include "Book.h"

void Book::add_new (string name, my_int phone, string email /*= "null"*/) {
    Abonent tmp;
    tmp.Name = name;
    tmp.Phones.insert(phone);
    tmp.Email = email;
    General.push_back(move(tmp));
    int current_index = General.size() - 1;
    Names.insert(pair  <string, int> (name, current_index));
    Phones.insert(pair <int, int> (phone, current_index));
}
void Book::output_all () const {
    for (unsigned int i = 0; i < General.size(); ++i) {
        cout << General[i].Name << " ";
        for (set <my_int> :: iterator it = General[i].Phones.begin(); it != General[i].Phones.end(); ++it) {
            cout << *it << " ";
        }
        cout << General[i].Email << endl;
    }
}
void Book::add_phone (string name, my_int phone) {
    if (Names.find(name) == Names.end())
        cout << "Error. This name (" << name << ") was not found" << endl;
    else {
        General[Names.find(name)->second].Phones.insert(phone);
        int current_index = General.size() - 1;
        Phones.insert(pair <int, int> (phone, current_index));
    }
}
void Book::replace_phone(string name, my_int old_phone, my_int new_phone) {
    if (Names.find(name) == Names.end())
        cout << "Error. This name (" << name << ") was not found" << endl;
    else
        if (General[Names.find(name)->second].Phones.find(old_phone) == General[Names.find(name)->second].Phones.end())
            cout << "Error. This phone (" << old_phone << ") was not found" << endl;
        else {
            General[Names.find(name)->second].Phones.erase(old_phone);
            Phones.erase(old_phone);
            this->add_phone(name, new_phone);
        }
}
void Book::find_name(my_int phone) {
    if (Phones.find(phone) == Phones.end())
        cout << "Error. This phone (" << phone << ") was not found" << endl;
    else
        cout << General[Phones.find(phone)->second].Name << endl;
}

