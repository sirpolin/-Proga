#include "Book.h"

int main() {
    Book b;
    string n, e;
    n = "Polin";
    e = "Polin@phystech.edu";
    b.add_new(n, 9266745528, e);
    b.output_all();
    b.add_phone(n, 9271140966);
    b.output_all();
    b.replace_phone(n, 9266745528, 9288279037);
    b.output_all();
    n = "Volodin";
    b.add_new(n, 9998881223);
    b.output_all();
    b.add_phone(n, 1234567890);
    b.output_all();
    cout << "----------------------------------" << endl;
    b.find_name(9266745528);
    return 0;
}

