#include "Vector.h"
#include "Point.h"
#include "Ray.h"
#include "Polygon.h"
#include <iomanip>

int main () {
	int n;
	cin >> n;
	Polygon P(n);
	for (int i = 0; i < n; ++i) {
		double x, y;
		cin >> x >> y;
		Point T(x,y);
		P[i] = T;
	}
	Polygon ans(n);
	P.graham_scan(ans);
	ans.print();


	return 0;
}