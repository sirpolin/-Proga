#pragma once
#include "Segment.h"

Segment::Segment (double x1, double y1, double x2, double y2) {
	a.putX(x1);
	b.putX(x2);
	a.putY(y1);
	b.putY(y2);
}
Segment::Segment (Point _a, Point _b) : a(_a), b(_b) {
}

int Segment::count_whole_points() const {
	int n1 = a.getX() - b.getX(), n2 = a.getY() - b.getY();
	int c;
    while (n2) {
       c = n1 % n2;
       n1 = n2;
       n2 = c;        
    }
    return abs(n1) - 1;
}