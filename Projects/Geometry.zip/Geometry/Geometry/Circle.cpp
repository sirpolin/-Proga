#pragma once

#include "Circle.h"

const double pi = 3.1415926;

Circle::Circle(const Point& a, double r): Point(a), R(r > 0 ? r : 1) {};
Circle::Circle(const Circle &a): Point (a), R(a.R) {};
double Circle::GetR () const {
	return R;
}
void Circle::PutR (double r) {
	R = r;
}
double Circle::area () const {
	return pi * R * R;
}
void Circle::Parametres () const {
	cout << "My centre is in ";
	this->Print();
	cout << "My radius is " << this->GetR() << endl;
}